<template>
  <v-container grid-list-md fluid>
    <v-row data-aos="fade" class="box-bg py-10">
      <v-container grid-list-md>
        <v-row>
          <v-col>
            <div div data-aos="fade-right" data-aos-delay="100" class="display-2 py-5">
              Misión
            </div>
            <div div data-aos="fade-right" data-aos-delay="200" class="headline">
              My Company tiene como misión vital de entrenar, dirigir y acompañar a todos los que sienten el deseo de obtener una mejor calidad de vida personal y familiar.
            </div>
          </v-col>
        </v-row>
      </v-container>
    </v-row>
  </v-container>
</template>

<script>
export default {

}
</script>

<style>

</style>