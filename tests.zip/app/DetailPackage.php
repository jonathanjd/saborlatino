<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetailPackage extends Model
{
    //
    protected $fillbale = [
        'feature', 'package_id'
    ];
}
