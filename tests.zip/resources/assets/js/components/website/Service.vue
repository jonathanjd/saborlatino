<template>
  <v-container grid-list-md fluid>
    <v-row class="box-bg-grey">
        <v-col>
          <div data-aos="zoom-in" class="text-lg-center display-2 py-2">Servicios</div>
          <div data-aos="fade-right" data-aos-delay="100" class="text-lg-center headline">Edificando Vidas y Famlias Saludables</div>
        </v-col>
    </v-row>
      <v-row class="box-bg-grey">
        <v-col>
          <v-card
          class="mx-auto"
          max-width="800"
        >
          <v-img
            data-aos="zoom-in"
            class="white--text align-end"
            height="400px"
            src="/img/service1.jpg"
          >
          </v-img>

          <v-card-text class="text--primary">
            <v-list shaped>
              <v-list-item-group color="primary">
                <v-list-item data-aos="flip-up" data-aos-delay="150">
                  <v-list-item-icon>
                    <v-icon>fas fa-circle</v-icon>
                  </v-list-item-icon>
                  <v-list-item-content>
                    <v-list-item-title>Coaching Personal</v-list-item-title>
                  </v-list-item-content>
                </v-list-item>
                <v-list-item data-aos="flip-up" data-aos-delay="200">
                  <v-list-item-icon>
                    <v-icon>fas fa-circle</v-icon>
                  </v-list-item-icon>
                  <v-list-item-content>
                    <v-list-item-title>Coaching Familiar</v-list-item-title>
                  </v-list-item-content>
                </v-list-item>
                <v-list-item data-aos="flip-up" data-aos-delay="250">
                  <v-list-item-icon>
                    <v-icon>fas fa-circle</v-icon>
                  </v-list-item-icon>
                  <v-list-item-content>
                    <v-list-item-title>Grupos de apoyo</v-list-item-title>
                  </v-list-item-content>
                </v-list-item>
                <v-list-item data-aos="flip-up" data-aos-delay="300">
                  <v-list-item-icon>
                    <v-icon>fas fa-circle</v-icon>
                  </v-list-item-icon>
                  <v-list-item-content>
                    <v-list-item-title>Manejo de temperamento</v-list-item-title>
                  </v-list-item-content>
                </v-list-item>
                <v-list-item data-aos="flip-up" data-aos-delay="350">
                  <v-list-item-icon>
                    <v-icon>fas fa-circle</v-icon>
                  </v-list-item-icon>
                  <v-list-item-content>
                    <v-list-item-title>Modificación de pensamiento, comportamiento y actitudes</v-list-item-title>
                  </v-list-item-content>
                </v-list-item>
                <v-list-item data-aos="flip-up" data-aos-delay="400">
                  <v-list-item-icon>
                    <v-icon>fas fa-circle</v-icon>
                  </v-list-item-icon>
                  <v-list-item-content>
                    <v-list-item-title>Coaching de salud y nutrición</v-list-item-title>
                  </v-list-item-content>
                </v-list-item>
              </v-list-item-group>
            </v-list>
            <v-divider></v-divider>
             <v-list subheader>
              <v-subheader data-aos="flip-up" data-aos-delay="450">Además ofrecemos programas de entrenamiento para la vida, personal y familiar.</v-subheader>
            </v-list>
          </v-card-text>

        </v-card>
        </v-col>
      </v-row>
    <v-row class="box-bg-grey">
      <v-col>
        <v-card
        class="mx-auto"
        max-width="800"
      >
        <v-img
          data-aos="zoom-in"
          class="white--text align-end"
          height="400px"
          src="/img/service2.jpg"
        >
        </v-img>

        <v-card-text class="text--primary">
          <div class="text-justify subtitle-1" data-aos="flip-up" data-aos-delay="500">
            Pa' Lante Moving Forward Coaching entrena, dirige y acompaña para que se logre la calidad de vida y salud emocional, espiritual y mental que se merece todo ser humano.
          </div>
          <div class="text-center subtitle-1 py-4" data-aos="flip-up" data-aos-delay="550">
            <strong>"Ama tu vida lo suficiente que logres un estilo de vida íntegro y saludable"</strong>
          </div>
        </v-card-text>

      </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {

}
</script>

<style>

</style>