<template>
  <h1>Admin Component</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>