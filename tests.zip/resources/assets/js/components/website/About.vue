<template>
  <v-container grid-list-md>
    <v-row>
      <v-col>

        <v-card data-aos="fade"
          class="mx-auto"
          max-width="800"
        >
          <v-img
            class="white--text align-end"
            height="400px"
            src="/img/who.jpg"
          >
            <v-card-title data-aos="fade-right" data-aos-delay="100" class="title">¿Quiénes somos?</v-card-title>
          </v-img>

          <v-card-text class="text--primary">
            <div data-aos="fade-right" data-aos-delay="200" class="text-justify subtitle-1">
              <strong>Pa' Lante Moving Forward Coaching</strong> se creó para ofrecer un entrenamiento en el crecimiento personal y familiar. Específico para aquellas personas que necesitan y creen que el bienestar y el rendimiento se consiguen a través de una dirección y una orientación profesional. Entrenamos y acompañamos a las personas en su proceso de cumplir sus objetivos, metas, propósitos y dirigirlos a que logren una satisfacción personal que los lleve a descubrir lo que realmente es importante en su vida.
            </div>
          </v-card-text>

        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {

}
</script>

<style>

</style>