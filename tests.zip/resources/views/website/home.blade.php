@extends('layouts.app')

@section('title', 'Home')

@section('content')
    <v-app style="background-color: white">
        <app></app>
    </v-app>
@endsection