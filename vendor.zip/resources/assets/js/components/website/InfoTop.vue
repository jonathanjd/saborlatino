<template>
  <v-container>
    <v-toolbar style="border-bottom: 2px solid black" flat>
      <v-toolbar-title></v-toolbar-title>
      <v-spacer></v-spacer>
      <v-btn icon>
        <v-icon>fab fa-facebook-f</v-icon>
      </v-btn>
      <v-btn icon>
        <v-icon>fab fa-instagram</v-icon>
      </v-btn>
    </v-toolbar>
  </v-container>
</template>

<script>
export default {

}
</script>

<style>

</style>